# Random couplings generator for FCC system

Generates a NxNxN FCC supercell and assigns random first nearest neighbor couplingsi drawn from a Gaussian distribution. Three files are written 
namely, momfile, posfile, and jfile which can be used as an input for Uppsala Spin Dynamics Code.
